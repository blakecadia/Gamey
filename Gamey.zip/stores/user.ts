export const useUserStore = defineStore("user", () => {
    const userData = ref<User>({
        _id: "",
        name: "",
        email: "",
        credits: [],
        plan: "",
    });
    const loaded = ref(false);
    const servers = ref<Server[]>([]);
    const shorts = ref<Short[]>([]);

    function getLoadedWatcher() {
        return loaded;
    }

    async function fetchData() {
        const { data, error } = await useFetch("/api/data", {
            method: "GET",
        });

        if (data.value?.servers && data.value?.user) {
            // @ts-ignore
            userData.value = data.value.user;
            // @ts-ignore
            servers.value = data.value.servers;
            // @ts-ignore
            shorts.value = data.value.shorts;
        }

        // console.log(shorts.value);
        loaded.value = true;
    }

    function getCredits() {
        return userData.value.credits.reduce((acc, cur) => acc + (cur.expires < Date.now() ? 0 : cur.amount), 0);
    }

    fetchData();

    return {
        getLoadedWatcher,
        fetchData,
        getCredits,
        data: userData,
        servers,
        shorts,
    };
});

export const shortInfoSettings = () => ({
    gamemode: "skyblock",
    script: "",
    server: "",
    font: "",
    voiceover: [],
    clips: {},
    music: "",
    finished: "",
    serverName: "",
    serverIp: "",
    serverPort: "",
    serverVersion: "",
    serverIcon: "",
    fontColor: "#ffffff",
    outlineColor: "#000000",
});
