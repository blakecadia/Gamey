import { stripe } from "~/server/utils/stripe";

export default defineEventHandler(async (event) => {
    if (!event.context.user)
        throw createError({
            statusCode: 401,
            statusMessage: "Not logged in",
        });

    const prices = await stripe.prices.list({
        expand: ["data.product"],
    });

    return prices.data.map((i) => ({
        lookup_key: i.lookup_key,
        // @ts-ignore
        name: i.product.name,
        price: i.unit_amount,
    }));
});
