import { stripe } from "~/server/utils/stripe";

export default defineEventHandler(async (event) => {
    if (!event.context.user)
        throw createError({
            statusCode: 401,
            statusMessage: "Not logged in",
        });

    const { lookup_key, success_url, error_url } = await readBody(event);

    const prices = await stripe.prices.list({
        lookup_keys: [lookup_key],
        expand: ["data.product"],
    });

    const session = await stripe.checkout.sessions.create({
        customer: event.context.user.stripeCustomer,
        billing_address_collection: "auto",
        line_items: [
            {
                price: prices.data[0].id,
                quantity: 1,
            },
        ],
        mode: "payment",
        success_url,
        cancel_url: error_url,
    });

    if (session.url) {
        return { url: session.url };
    }
});
