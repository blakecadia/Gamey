import { stripe } from "~/server/utils/stripe";

export default defineEventHandler(async (event) => {
    if (!event.context.user)
        throw createError({
            statusCode: 401,
            statusMessage: "Not logged in",
        });

    const prices = await stripe.prices.list({
        lookup_keys: ["plan_basic"],
        expand: ["data.product"],
    });

    const subscriptions = await stripe.subscriptions.list({
        customer: event.context.user.stripeCustomer,
    });

    var found = false;
    for (const subscription of subscriptions.data) {
        const items = subscription.items.data;
        for (const item of items) {
            if (item.price.lookup_key === "plan_premium") {
                // Cancel the subscription
                await stripe.subscriptions.update(subscription.id, {
                    items: [
                        {
                            id: item.id,
                            price: prices.data[0].id,
                        },
                    ],
                });

                event.context.user.plan = "basic";
                await event.context.user.save();
                found = true;
            }
        }
    }

    if (!found) {
        throw createError({
            statusCode: 400,
            statusMessage: "Not logged in",
        });
    }

    return "";
});
