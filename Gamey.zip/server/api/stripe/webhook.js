import { stripe } from "~/server/utils/stripe";

const runtimeConfig = useRuntimeConfig();

export default eventHandler(async (event) => {
    const body = await readRawBody(event, false);
    let stripeEvent = body;
    const signature = getHeader(event, "stripe-signature");

    if (!body || !signature) {
        throw createError({
            statusCode: 400,
            statusMessage: "Invalid body or signature",
        });
    }

    try {
        stripeEvent = stripe.webhooks.constructEvent(body, signature, runtimeConfig.STRIPE_WEBHOOK);
    } catch (err) {
        throw createError({
            statusCode: 400,
            statusMessage: `Webhook error ${err}`,
        });
    }

    const user = await User.findOne({
        stripeCustomer: stripeEvent.data.object.customer,
    });

    if (!user)
        return createError({
            statusCode: 400,
            statusMessage: "Invalid customer",
        });

    var subscriptionId, subscription, subscriptionName;

    switch (stripeEvent.type) {
        case "checkout.session.completed":
            const lineItems = await stripe.checkout.sessions.listLineItems(stripeEvent.data.object.id);
            const lookup_key = lineItems.data[0].price?.lookup_key;
            if (lookup_key?.includes("credits")) {
                const creditCount = Number(lookup_key.replace("credits_", ""));
                user.credits.push({
                    amount: creditCount,
                    expires: Date.now() + 2 * 30 * 24 * 60 * 60 * 1000,
                });
                await user.save();
            }
            break;
        case "customer.subscription.deleted":
            subscriptionId = stripeEvent.data.object.subscription;
            console.log(subscriptionId);
            subscription = await stripe.subscriptions.retrieve(subscriptionId);
            subscriptionName = subscription.items.data[0].price.lookup_key;

            if (subscriptionName?.replaceAll("plan_", "") == user.plan) {
                user.plan = null;
                await user.save();
            }
            break;
        case "invoice.paid":
            subscriptionId = stripeEvent.data.object.subscription;
            subscription = await stripe.subscriptions.retrieve(subscriptionId);
            subscriptionName = subscription.items.data[0].price.lookup_key;

            // Cancel old plan
            if (subscriptionName == "plan_premium" && user.plan == "basic") {
                const subscriptions = await stripe.subscriptions.list({
                    customer: user.stripeCustomer,
                });

                for (const subscription of subscriptions.data) {
                    const items = subscription.items.data;
                    for (const item of items) {
                        if (item.price.lookup_key === "plan_basic") {
                            // Cancel the subscription
                            await stripe.subscriptions.cancel(subscription.id);
                        }
                    }
                }
            }

            switch (subscriptionName) {
                case "plan_basic":
                    user.plan = "basic";
                    user.credits.push({
                        amount: 30,
                        expires: Date.now() + 2 * 30 * 24 * 60 * 60 * 1000,
                    });
                    break;
                case "plan_premium":
                    user.plan = "premium";
                    user.credits.push({
                        amount: 60,
                        expires: Date.now() + 2 * 30 * 24 * 60 * 60 * 1000,
                    });
                    break;
                default:
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    console.log(`PANIC!!! User ${user.email} purchased invalid subscription ${subscriptionName}`);
                    throw createError({
                        statusCode: 500,
                        statusMessage: "PANIC!",
                    });
            }
            await user.save();
            break;
    }
});
