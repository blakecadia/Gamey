import { stripe } from "~/server/utils/stripe";

export default eventHandler(async (event) => {
    if (!event.context.user)
        throw createError({
            statusCode: 401,
            statusMessage: "Not logged in",
        });

    const portalSession = await stripe.billingPortal.sessions.create({
        customer: event.context.user.stripeCustomer,
    });

    return { url: portalSession.url };
});
