export default eventHandler(async (event) => {
    const {
        files,
        name,
        namePronunciation,
        ip,
        ipPronunciation,
        version,
        port,
    }: any = await readBody<{ files: File[] }>(event);

    if (
        files[0].type != "image/png" &&
        files[0].type != "image/jpeg" &&
        files[0].type != "image/jpg"
    )
        return false;

    const iconPath = await storeFileLocally(files[0], 16);

    const server = new Server({
        owner: event.context.user._id,
        name,
        namePronunciation,
        ip,
        ipPronunciation,
        version,
        iconPath: `public/server-icons/${iconPath}`,
        port,
    });

    await server.save();

    return true;
});
