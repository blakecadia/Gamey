export {};

declare global {
    interface Server {
        name: string;
        namePronunciation: string;
        _id: string;
        ip: string;
        ipPronuncation: string;
        iconPath: string;
        version: string;
    }

    interface Short {
        link: string;
        serverName: string;
        serverIp: string;
        serverPort: string;
        serverVersion: string;
        serverIcon: string;
    }

    interface User {
        _id: string;
        email: string;
        name: string;
        credits: CreditEntry[];
        plan: string;
    }

    interface CreditEntry {
        amount: number;
        expires: number;
    }
}
